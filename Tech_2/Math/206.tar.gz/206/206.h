/*
** 206.h for 206 in /home/belia-_r/afs/Math/206
**
** Made by belia-_r
** Login   <belia-_r@epitech.net>
**
** Started on  Sun Apr 29 11:30:30 2012 belia-_r
** Last update Sun Apr 29 12:16:16 2012 belia-_r
*/

#ifndef __206_H__
#define __206_H__

#include	<stdio.h>

int		open_path(char *path, float **tab);
void*		xmalloc(size_t size);
int		xfclose(FILE *fp);

#endif /* __206_H__ */
