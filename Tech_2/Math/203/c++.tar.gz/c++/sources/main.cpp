//
// main.cpp for 203hotline in /home/belia-_r/afs/epitech_perso/Tech_2/Math/203/c++
//
// Made by romain belia-bourgeois
// Login   <belia-_r@epitech.net>
//
// Started on  Sat Mar 23 20:53:43 2013 romain belia-bourgeois
// Last update Sat Mar 23 20:58:30 2013 romain belia-bourgeois
//

#include	<iostream>
#include	<string>
#include	<sstream>

template<typename T>
T StringToNumber(const std::string& numberAsString)
{
  T valor;

  std::stringstream stream(numberAsString);
  stream >> valor;

  return valor;
}

double Factorial(double nValue)
{
  double result = nValue;
  double result_next;
  double pc = nValue;

  do
    {
      result_next = result*(pc-1);
      result = result_next;
      pc--;
    }while(pc>2);
  nValue = result;
  return nValue;
}

double EvaluateBinomialCoefficient(double nValue, double nValue2)
{
  double result;
  if(nValue2 == 1)return nValue;
  result = (Factorial(nValue))/(Factorial(nValue2)*Factorial((nValue - nValue2)));
  nValue2 = result;
  return nValue2;
}


double		binomial(double n, double k)
{
  double	value = 0;

  if (k == 0 || k == n)
    return (1.0);
  else
    {
      value = value + (binomial(n-1,k-1) + binomial(n+1,k));
    }
  return (value);
}

double		min(double a, double b)
{
  return ((a <= b) ? a : b);
}

double		 coeff_binomial(double n, double k)
{
  double	b = 1.0;
  double	i = 1.0;
  double       	k2;

  if ((k < 0) || (k > n)){
    return (0);}
  k2 = min(k, (n - k));
  while (i <= k2)
    {
      b = ((b * (n - i + 1.0)) / i);
      i++;
    }
  return (b);
}

int		main(int ac, char **av)
{
  if (ac >= 3)
    {
      double nb1 = StringToNumber<double>(av[1]);
      double nb2 = StringToNumber<double>(av[2]);
      std::cout.precision(30);
      std::cout<<"The Binomial Coefficient of 1000000, and 5, is equal to: "<< EvaluateBinomialCoefficient(nb1, nb2) << std::endl;
      std::cout << "binomial(1000000, 5) is " << coeff_binomial(nb1, nb2) << std::endl;
    }
}
