#include "koala.h"

int	main(void)
{
	/*
	 * Ces fonctions sont dans une librairie ...
	 */
	koala* zaz = new_koala("zaz", 23, "rah, la flemme !");
	introduce_koala(zaz);
	delete_koala(zaz);

	return (0);
}
