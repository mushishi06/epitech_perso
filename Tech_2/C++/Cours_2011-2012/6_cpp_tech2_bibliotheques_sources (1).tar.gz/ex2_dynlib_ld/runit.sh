#!/bin/bash

echo "> ldd exemple2"
ldd ./exemple2

echo "> ./exemple2"

./exemple2

echo "> export LD_LIBRARY_PATH=\"./\""
export LD_LIBRARY_PATH="./"

echo "> ldd exemple2"

ldd ./exemple2

echo "> ./exemple2"

./exemple2

