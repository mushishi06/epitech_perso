#include <iostream>
#include "Koala.hh"

//Implementation de la methode talk()
void Koala::talk() const
{
	std::cout << "Koala says KREOOOOOOOOOOG !" << std::endl;
}

//Fonction de creation du Koala
//Sera appellee depuis le coeur pour recuperer une instance de Koala

extern "C"
{
	IAssistant* create_assistant()
	{
		return new Koala();
	}
}
