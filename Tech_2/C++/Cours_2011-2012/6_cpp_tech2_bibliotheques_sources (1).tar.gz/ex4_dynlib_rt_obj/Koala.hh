#ifndef __KOALA_HH__
# define __KOALA_HH__

# include "IAssistant.hh" //Besoin d'inclure l'interface depuis le core

class Koala : public IAssistant
{
	public:
		virtual void talk() const;
};
#endif
