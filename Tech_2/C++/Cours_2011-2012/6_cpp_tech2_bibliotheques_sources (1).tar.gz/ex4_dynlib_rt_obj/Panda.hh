#ifndef __PANDA_HH__
# define __PANDA_HH__

# include "IAssistant.hh" //Besoin d'inclure l'interface depuis le core

class Panda : public IAssistant
{
	public:
		virtual void talk() const;
};
#endif
