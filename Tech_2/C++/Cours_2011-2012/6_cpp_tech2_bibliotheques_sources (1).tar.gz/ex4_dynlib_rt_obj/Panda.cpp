#include <iostream>
#include "Panda.hh"

//Implementation de la methode talk()
void Panda::talk() const
{
	std::cout << "Panda says PONEY PONEY !" << std::endl;
}

//Fonction de creation du Panda
//Sera appellee depuis le coeur pour recuperer une instance de Panda

extern "C"
{
	IAssistant* create_assistant()
	{
		return new Panda();
	}
}
