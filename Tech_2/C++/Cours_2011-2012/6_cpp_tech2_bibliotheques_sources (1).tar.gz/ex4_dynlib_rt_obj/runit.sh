#!/bin/bash

echo "> ldd exemple4"
ldd ./exemple4

echo "> ./exemple4"
./exemple4

echo "> ./exemple4 ./libkoala.so"
./exemple4 ./libkoala.so

echo "> ./exemple4 ./libpanda.so"
./exemple4 ./libpanda.so
