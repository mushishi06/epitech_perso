#ifndef IASSISTANT_HH__
# define IASSISTANT_HH__

class IAssistant
{
	public:
		virtual void talk() const = 0;
};

#endif
