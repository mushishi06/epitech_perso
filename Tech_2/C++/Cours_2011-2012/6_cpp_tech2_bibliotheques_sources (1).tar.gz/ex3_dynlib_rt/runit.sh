#!/bin/bash

echo "> ldd exemple3"
ldd ./exemple3

echo "> mv libkoala.so libkoala.so.old"
mv libkoala.so libkoala.so.old
echo "> ./exemple3"
./exemple3
echo "> mv libkoala.so.old libkoala.so"
mv libkoala.so.old libkoala.so
echo "> ./exemple3"
./exemple3
