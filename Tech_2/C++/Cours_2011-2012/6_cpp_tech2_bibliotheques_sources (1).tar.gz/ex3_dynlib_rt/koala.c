#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "koala.h"

void		kreog_dance(int times)
{
	int 	i;

	for (i = 0; i < times; ++i)
	{
			printf("Do the D A N C E ! KREOOOOOOOG !\n");
	}
}
