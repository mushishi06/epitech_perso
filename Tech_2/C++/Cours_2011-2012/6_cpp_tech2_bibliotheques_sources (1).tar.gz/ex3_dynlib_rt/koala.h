#ifndef __KOALA_H__
# define __KOALA_H__

void	kreog_dance(int);

#endif
