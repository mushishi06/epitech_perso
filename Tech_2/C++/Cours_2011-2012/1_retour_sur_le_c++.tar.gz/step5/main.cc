/******************************************************************************/
/*                                                                            */
/*                        main.c for the list project                         */
/*                        Made by David GIRON and Maxime MONTINET             */
/*                                                                            */
/******************************************************************************/

#include <iostream> /* cout, endl */
#include <iomanip> /* boolalpha */
#include <cstring> /* strlen */

#include "list.hh"
#include "item.hh"

/*
 * Structure d'exemple representant un Koala
 */
struct Koala : public Item
{
        std::string nom;
        int age;
        std::string catchphrase;

        Koala(std::string const & n, int a, std::string const & c) : nom(n), age(a), catchphrase(c) {}

        bool operator==(Item const & other) const
        {
            Koala const * tmp = dynamic_cast<Koala const *>(&other);
            if (tmp == 0)
                return false;
            return (tmp->nom == this->nom
                    && tmp->age == this->age
                    && tmp->catchphrase == this->catchphrase);
        }

        void identify() const
        {
            std::cout << "Koala " << nom << " aged " << age << " : " << catchphrase << std::endl;
        }
};

/*
 * Structure d'exemple representant un etudiant
 */
struct Etudiant : public Item
{
        std::string login;

        Etudiant(std::string const & n) : login(n) {}

        bool operator==(Item const & other) const
        {
            Etudiant const * tmp = dynamic_cast<Etudiant const *>(&other);
            if (tmp == 0)
                return false;
            return (this->login == tmp->login);
        }

        void identify() const
        {
            std::cout << login << ": Ca marche paaaaaaaaaaaaaaas !" << std::endl;
        }
};

/*
 * Fonction helper appelant Identify sur un item
 */
static void dump_item(Item const & item)
{
    item.identify();
}

int main()
{
    /*
     * Creons une liste d'etudiants et une de koalas
     */
    List* list_koala = new List();
    list_koala->add_back(new Koala("zaz", 42, "la flemme, deux fois, en diagonale, sur un poney"));
    list_koala->add_back(new Koala("jack", 84, "moi je peux me deguiser en pompe a essence !"));
    list_koala->add_back(new Koala("thor", 168, "ta musique c'est de la merde, mets du black metal !"));

    List* list_etud = new List();
    list_etud->add_back(new Etudiant("troudba_l"));
    list_etud->add_back(new Etudiant("lustucr_u"));

    /*
     * Appliquons des fonctions a nos listes
     */
    list_koala->iter(&dump_item);
    list_etud->iter(&dump_item);

    /*
     * Quelques tests de presence d'elements
     */

    std::cout << "Presence du Koala zaz  dans list_koala : " << std::boolalpha << list_koala->mem(Koala("zaz", 42, "la flemme, deux fois, en diagonale, sur un poney")) << std::endl;
    std::cout << "Presence du Koala zaz  dans list_etud : " << std::boolalpha << list_etud->mem(Koala("zaz", 42, "la flemme, deux fois, en diagonale, sur un poney")) << std::endl;
    std::cout << "Presence de l'etudiant troudba_l dans list_koala : " << std::boolalpha << list_koala->mem(Etudiant("troudba_l")) << std::endl;
    std::cout << "Presence de l'etudiant troudba_l dans list_etud : " << std::boolalpha << list_etud->mem(Etudiant("troudba_l")) << std::endl;


    delete list_koala;
    delete list_etud;

    return 0;
}

