/******************************************************************************/
/*                                                                            */
/*                        main.c for the list project                         */
/*                        Made by David GIRON and Maxime MONTINET             */
/*                                                                            */
/******************************************************************************/

#include <iostream> /* cout, endl */
#include <cstring> /* strlen */

#include "list.hh"
#include "item.hh"

/*
 * Structure d'exemple representant un Koala
 */
struct Koala
{
    std::string nom;
    int age;
    std::string catchphrase;

    Koala(std::string n, int a, std::string c) : nom(n), age(a), catchphrase(c) {}
};

/*
 * Fonction helper affichant le contenu d'un element de type chaine
 */
static void dump_string(void * content, int len)
{
    std::cout << "  Content [" << static_cast<char*>(content) << "], len [" << len << "]" << std::endl;
}

/*
 * Fonction helper affichant les attributs d'un Koala
 */
static void dump_koala(void * content, int)
{
    Koala * bob = (Koala *)content;

    std::cout << "  " << bob->nom << " est age de " << bob->age << " annees et dit \"" << bob->catchphrase << "\"" << std::endl;
}

int main()
{
    char test_contents[][4] = {"ga", "bu", "zo", "meu"};
    char needle[] = "meu";

    /*
     * On cree une liste et on la remplit avec quelques chaines
     * de caracteres de test
     */
    List* list = new List();
    for (int i = 0; i < 4; ++i)
    {
        list->add_front(test_contents[i], strlen(test_contents[i]));
    }
    std::cout << "Elements dans la liste :" << std::endl;
    list->iter(&dump_string);

    if (list->mem(needle, 3))
        std::cout << "[meu] est dans la liste (OK)" << std::endl;
    else
    {
        std::cout << "[meu] n'est PAS dans la liste, erreur !" << std::endl;
        return 1;
    }

    delete list;

    /*
     * On cree une autre liste et on la remplit avec des Koala
     */
    list = new List();
    list->add_back(new Koala("zaz", 42, "la flemme ..."), sizeof(Koala));
    list->add_back(new Koala("jack", 84, "c'est une RUMEUR !"), sizeof(Koala));
    list->add_back(new Koala("thor", 168, "Proceed..."), sizeof(Koala));
    std::cout << "Koalas dans la liste :" << std::endl;
    list->iter(&dump_koala);

    delete list;

    return 0;
}

