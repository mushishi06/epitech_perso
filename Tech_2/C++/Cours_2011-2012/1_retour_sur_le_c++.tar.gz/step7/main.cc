/******************************************************************************/
/*                                                                            */
/*                   main.c for the list project                              */
/*                   Made by David GIRON & Maxime MONTINET                    */
/*                                                                            */
/******************************************************************************/

#include <iostream> /* cout, endl */
#include <iomanip> /* boolalpha */

#include <list>
#include <algorithm>

/*
 * Structure d'exemple representant un Koala
 */
struct Koala
{
        std::string nom;
        int age;
        std::string catchphrase;

        Koala(std::string const & n, int a, std::string const & c) : nom(n), age(a), catchphrase(c) {}

        void identify() const
        {
            std::cout << "Koala " << nom << " aged " << age << " : " << catchphrase << std::endl;
        }

        bool operator==(Koala const & other)
        {
            return (this->nom == other.nom
                    && this->age == other.age
                    && this->catchphrase == other.catchphrase);
        }
};

/*
 * Structure d'exemple representant un etudiant
 */
struct Etudiant
{
        std::string login;

        Etudiant(std::string const & n) : login(n) {}

        void identify() const
        {
            std::cout << login << ": Ca marche paaaaaaaaaaaaaaas !" << std::endl;
        }

        bool operator==(Etudiant const & other)
        {
            return (this->login == other.login);
        }
};

/*
 * Fonction helper appelant Identify
 */
template<typename T>
void dumpit(T& ga) { ga.identify(); }

int main()
{
    /*
     * Creons une liste d'etudiants et une de koalas
     */
    std::list<Koala> list_koala;
    list_koala.push_back(Koala("zaz", 42, "la flemme, deux fois, en diagonale, sur un poney"));
    list_koala.push_back(Koala("jack", 84, "moi je peux me deguiser en pompe a essence !"));
    list_koala.push_back(Koala("thor", 168, "ta musique c'est de la merde, mets du black metal !"));

    std::list<Etudiant> list_etud;
    list_etud.push_back(Etudiant("troudba_l"));
    list_etud.push_back(Etudiant("lustucr_u"));

    /*
     * Appliquons des fonctions a nos listes
     */
    std::for_each(list_koala.begin(), list_koala.end(), &dumpit<Koala>);
    std::for_each(list_etud.begin(), list_etud.end(), &dumpit<Etudiant>);

    /*
     * Quelques tests de presence d'elements
     */
    std::list<Koala>::const_iterator it1 = std::find(list_koala.begin(), list_koala.end(), Koala("zaz", 42, "la flemme, deux fois, en diagonale, sur un poney"));
    std::list<Etudiant>::const_iterator it2 = std::find(list_etud.begin(), list_etud.end(), Etudiant("troudba_l"));
    std::cout << "Presence du Koala zaz  dans list_koala : " << std::boolalpha << (it1 != list_koala.end()) << std::endl;
    std::cout << "Presence de l'etudiant troudba_l dans list_etud : " << std::boolalpha << (it2 != list_etud.end()) << std::endl;

    return 0;
}

