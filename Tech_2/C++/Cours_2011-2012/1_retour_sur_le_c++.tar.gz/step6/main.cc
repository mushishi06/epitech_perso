/******************************************************************************/
/*                                                                            */
/*                        main.c for the list project                         */
/*                        Made by David GIRON and Maxime MONTINET             */
/*                                                                            */
/******************************************************************************/

#include <iostream> /* cout, endl */
#include <iomanip> /* boolalpha */

#include "list.hpp"

/*
 * Structure d'exemple representant un Koala
 */
struct Koala
{
        std::string nom;
        int age;
        std::string catchphrase;

        Koala(std::string const & n, int a, std::string const & c) : nom(n), age(a), catchphrase(c) {}

        void identify() const
        {
            std::cout << "Koala " << nom << " aged " << age << " : " << catchphrase << std::endl;
        }

        bool operator==(Koala const & other)
        {
            return (this->nom == other.nom
                    && this->age == other.age
                    && this->catchphrase == other.catchphrase);
        }
};

/*
 * Structure d'exemple representant un etudiant
 */
struct Etudiant
{
        std::string login;

        Etudiant(std::string const & n) : login(n) {}

        void identify() const
        {
            std::cout << login << ": Ca marche paaaaaaaaaaaaaaas !" << std::endl;
        }

        bool operator==(Etudiant const & other)
        {
            return (this->login == other.login);
        }
};

/*
 * Fonction helper appelant Identify
 */
template<typename T>
void dumpit(T& ga) { ga.identify(); }

int main()
{
    /*
     * Creons une liste d'etudiants et une de koalas
     */
    List<Koala>* list_koala = new List<Koala>();
    list_koala->push_back(Koala("zaz", 42, "la flemme, deux fois, en diagonale, sur un poney"));
    list_koala->push_back(Koala("jack", 84, "moi je peux me deguiser en pompe a essence !"));
    list_koala->push_back(Koala("thor", 168, "ta musique c'est de la merde, mets du black metal !"));

    List<Etudiant>* list_etud = new List<Etudiant>();
    list_etud->push_back(Etudiant("troudba_l"));
    list_etud->push_back(Etudiant("lustucr_u"));

    /*
     * Appliquons des fonctions a nos listes
     */
    list_koala->iter(&dumpit<Koala>);
    list_etud->iter(&dumpit<Etudiant>);

    /*
     * Quelques tests de presence d'elements
     */

    std::cout << "Presence du Koala zaz  dans list_koala : " << std::boolalpha << list_koala->mem(Koala("zaz", 42, "la flemme, deux fois, en diagonale, sur un poney")) << std::endl;
    std::cout << "Presence de l'etudiant troudba_l dans list_etud : " << std::boolalpha << list_etud->mem(Etudiant("troudba_l")) << std::endl;


    delete list_koala;
    delete list_etud;

    return 0;
}

