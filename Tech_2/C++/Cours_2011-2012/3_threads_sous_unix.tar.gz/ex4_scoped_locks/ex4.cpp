/******************************************************************************/
/*                                                                            */
/*           ex4.cpp in ex4_scopedlock in 3_threads_sous_unix                 */
/*           For Epitech's C++ Knowledge Unit                                 */
/*           Made by : Uriel Corfa <uriel@corfa.fr>                           */
/*           Modified by : David Giron <thor@epitech.net>                     */
/*                                                                            */
/******************************************************************************/



#include <map>
#include <string>
#include <iostream>
#include <algorithm>
#include <exception>
#include <stdexcept>

#include <pthread.h>

#include "scoped_lock.hh"


/******************************************************************************/


struct			s_counter
{
  int *			counter;
  pthread_mutex_t *	mutex;
};

// Cas le plus simple
void *	lock_and_doSomething(void * r)
{
  s_counter * c = reinterpret_cast<s_counter *>(r);
  pthread_mutex_lock(c->mutex);
  *(c->counter)++;
  pthread_mutex_unlock(c->mutex);
  return NULL;
}


/******************************************************************************/


struct s_map
{
  std::map<std::string, std::string> *	m;
  pthread_mutex_t *		        mutex;
};

// Cas plus réaliste
void *	lock_and_doSomething2(void * r)
{
  s_map * m = reinterpret_cast<s_map *>(r);

  pthread_mutex_lock(m->mutex);

  std::cout << "Now going to filter the map..." << std::endl;
    
  if (m->m->size() == 0)
    return NULL; // DANGER !

  for (std::map<std::string, std::string>::iterator it = m->m->begin();
       it != m->m->end();
       ++it)
    {
      if (it->second.size() == 0)
	it->second = "<empty>";
      else if (it->second == "<invalid>")
	throw std::runtime_error("Map contains invalid entries"); // DANGER !
    }
  
  std::cout << "Done with the map" << std::endl;
  
  pthread_mutex_unlock(m->mutex);
}


/******************************************************************************/


// Cas plus réaliste, version saine
void *	lock_and_doSomething3(void * r)
{
  s_map * m = reinterpret_cast<s_map *>(r);
  scoped_lock l_mutex(m->mutex);

  std::cout << "Now going to filter the map..." << std::endl;
  
  if (m->m->size() == 0)
    return NULL; // Destruction de l_mutex
  
  for (std::map<std::string, std::string>::iterator it = m->m->begin();
       it != m->m->end();
       ++it)
    {
      if (it->second.size() == 0)
	it->second = "<empty>";
      else if (it->second == "<invalid>")
	throw std::runtime_error("Map contains invalid entries"); // Destruction de l_mutex
    }

  std::cout << "Done with the map" << std::endl;
}


/******************************************************************************/


int	main(void)
{
  pthread_t thr1;
  pthread_t thr2;
  pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
  s_counter c = {0, &mutex};
  std::map<std::string, std::string> _m;
  s_map m = {&_m, &mutex};
  void * returned_value = NULL;

  _m.insert(std::pair<std::string, std::string>(std::string("David" ), std::string("Thor"   )));
  _m.insert(std::pair<std::string, std::string>(std::string("Uriel" ), std::string("Korfuri")));
  _m.insert(std::pair<std::string, std::string>(std::string("Maxime"), std::string("Zaz"    )));

  pthread_create(&thr1, NULL, &lock_and_doSomething2, &m);
  pthread_create(&thr2, NULL, &lock_and_doSomething2, &m);

  pthread_join(thr1, &returned_value);
  pthread_join(thr2, &returned_value);

  return 0;
}



/******************************************************************************/
