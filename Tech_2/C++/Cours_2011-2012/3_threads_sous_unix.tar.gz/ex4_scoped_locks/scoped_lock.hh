/******************************************************************************/
/*                                                                            */
/*           scoped_lock.hh in ex4_scopedlock in 3_threads_sous_unix          */
/*           For Epitech's C++ Knowledge Unit                                 */
/*           Made by : Uriel Corfa <uriel@corfa.fr>                           */
/*           Modified by : David Giron <thor@epitech.net>                     */
/*                                                                            */
/******************************************************************************/



#ifndef SCOPED_LOCK_HH_
#define SCOPED_LOCK_HH_


#include <pthread.h>


class scoped_lock
{

public:

  scoped_lock(pthread_mutex_t* mutex) :
    mutex_(mutex) // Stocke le mutex associé
  { 
    pthread_mutex_lock(mutex_); // Verrouille le mutex
  }

    ~scoped_lock(void)
  {
    pthread_mutex_unlock(mutex_); // Déverrouille le mutex
  }
    
private:
    scoped_lock(scoped_lock const&); // Interdit la copie
    scoped_lock& operator=(scoped_lock const&); // Interdit operator=

    pthread_mutex_t*    mutex_;
};


#endif /* SCOPED_LOCK_HH_                                                     */



/******************************************************************************/
