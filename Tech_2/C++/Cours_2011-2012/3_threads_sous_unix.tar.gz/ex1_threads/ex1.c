/******************************************************************************/
/*                                                                            */
/*              ex1.c in ex1_threads in 3_threads_sous_unix                   */
/*              For Epitech's C++ Knowledge Unit                              */
/*              Made by : Uriel Corfa <uriel@corfa.fr>                        */
/*              Modified by : David Giron <thor@epitech.net>                  */
/*                                                                            */
/******************************************************************************/



#include <stdlib.h>
#include <stdio.h>

#include <pthread.h>


void *	expensiveComputation1(void* param)
{
  printf("Starting expensive computation 1...\n");
  sleep(3);
  printf("Expensive computation 1 done.\n");
  return param;
}


void *	expensiveComputation2(void* param)
{
  printf("Starting expensive computation 2...\n");
  sleep(6);
  printf("Expensive computation 2 done.\n");
  return param;
}


int	main(void)
{
  pthread_t thr1;
  pthread_t thr2;

  pthread_create(&thr1, NULL, &expensiveComputation1, NULL);
  pthread_create(&thr2, NULL, &expensiveComputation2, NULL);

  void* returned_value;
  pthread_join(thr1, &returned_value);
  printf("Task 1 finished with value %p\n", returned_value);

  pthread_join(thr2, &returned_value);
  printf("Task 2 finished with value %p\n", returned_value);

  return 0;
}



/******************************************************************************/
