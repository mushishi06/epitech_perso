/******************************************************************************/
/*                                                                            */
/*            DataPacket.hh in ex3_convars in 3_threads_sous_unix             */
/*            For Epitech's C++ Knowledge Unit                                */
/*            Made by : Uriel Corfa <uriel@corfa.fr>                          */
/*            Modified by : David Giron <thor@epitech.net>                    */
/*                                                                            */
/******************************************************************************/



#ifndef DATAPACKET_HH_
#define DATAPACKET_HH_


typedef unsigned int DataPacket;


#endif /* DATAPACKET_HH_                                                      */



/******************************************************************************/
