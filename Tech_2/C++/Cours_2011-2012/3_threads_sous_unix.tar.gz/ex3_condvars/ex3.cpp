/******************************************************************************/
/*                                                                            */
/*              ex3.cpp in ex3_convars in 3_threads_sous_unix                 */
/*              For Epitech's C++ Knowledge Unit                              */
/*              Made by : Uriel Corfa <uriel@corfa.fr>                        */
/*              Modified by : David Giron <thor@epitech.net>                  */
/*                                                                            */
/******************************************************************************/



#include <iostream>
#include <list>

#include <pthread.h>

#include "safe_cout.hh"

#include "DataPacket.hh"
#include "Producer.hh"
#include "Consumer.hh"


// Configuration
static unsigned int const nb_producers = 2;
static unsigned int const nb_consumers = 3;


// Mutex for std::cout
pthread_mutex_t mutex_for_cout = PTHREAD_MUTEX_INITIALIZER;



/******************************************************************************/



int	main(void)
 {
   pthread_mutex_t mutex_for_queue = PTHREAD_MUTEX_INITIALIZER;
   pthread_cond_t cond_for_queue = PTHREAD_COND_INITIALIZER;
   std::list<DataPacket *> queue;
   std::list<std::pair<Producer *, pthread_t *> > producers;
   std::list<std::pair<Consumer *, pthread_t *> > consumers;
   volatile bool done = false;
    
   for (unsigned int i = 0; i < nb_consumers; ++i)
     {
       Consumer *  c = new Consumer(i, &done, &queue, &mutex_for_queue, &cond_for_queue);
       pthread_t * t = new pthread_t;
       std::pair<Consumer *, pthread_t *> couple(c, t);

       pthread_create(t, NULL, &consumer_start, (void *) c);
       consumers.push_back(couple);
     }

   for (unsigned int i = 0; i < nb_producers; ++i)
     {
       Producer *  p = new Producer(i, &queue, &mutex_for_queue, &cond_for_queue);
       pthread_t * t = new pthread_t;
       std::pair<Producer *, pthread_t *> couple(p, t);

       pthread_create(t, NULL, &producer_start, (void *) p);
       producers.push_back(couple);
     }

   for (unsigned int i = 0; i < nb_producers; ++i)
     {
       std::pair<Producer *, pthread_t *> couple = producers.back();
       void *ret_value;

       pthread_join(*(couple.second), &ret_value);
       delete couple.first; delete couple.second;
       producers.pop_back();
     }

   done = true;
   for (unsigned int i = 0; i < nb_consumers; ++i)
     {
       std::pair<Consumer *, pthread_t *> couple = consumers.back();
       void *ret_value;

       pthread_cond_broadcast(&cond_for_queue);
       pthread_join(*(couple.second), &ret_value);
       delete couple.first; delete couple.second;
       consumers.pop_back();
     }
   return 0;
 }



/******************************************************************************/
