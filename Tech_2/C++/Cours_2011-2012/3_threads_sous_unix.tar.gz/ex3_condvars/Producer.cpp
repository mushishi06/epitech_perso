/******************************************************************************/
/*                                                                            */
/*              Producer.cpp in ex3_convars in 3_threads_sous_unix            */
/*              For Epitech's C++ Knowledge Unit                              */
/*              Made by : Uriel Corfa <uriel@corfa.fr>                        */
/*              Modified by : David Giron <thor@epitech.net>                  */
/*                                                                            */
/******************************************************************************/



#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include "safe_cout.hh"

#include "DataPacket.hh"
#include "Producer.hh"


Producer::Producer(int id, std::list<DataPacket *> * queue,
		   pthread_mutex_t * mutex,
		   pthread_cond_t * cond) :
  id_(id),
  queue_(queue),
  mutex_(mutex),
  cond_(cond)
{
  pthread_mutex_lock(&mutex_for_cout);
  std::cout << "New producer..." << std::endl;
  pthread_mutex_unlock(&mutex_for_cout);
}


Producer::~Producer()
{
  pthread_mutex_lock(&mutex_for_cout);
  std::cout << "Delete producer..." << std::endl;
  pthread_mutex_unlock(&mutex_for_cout);
}



/******************************************************************************/



void	Producer::start()
{
  for (unsigned int i = 0; i < 3; ++i)
    {
      DataPacket * packet = new DataPacket(rand() % 42); // On produit
      pthread_mutex_lock(this->mutex_);
      sleep(delay_to_produce);
      this->queue_->push_back(packet);
      pthread_mutex_lock(&mutex_for_cout);
      std::cout << "P" << this->id_ << " produced a data packet..." << std::endl;
      pthread_mutex_unlock(&mutex_for_cout);
      pthread_mutex_unlock(this->mutex_);
      pthread_cond_signal(this->cond_); // On signale
      pthread_mutex_lock(&mutex_for_cout);
      std::cout << "P" << this->id_ << " signaled..." << std::endl;
      pthread_mutex_unlock(&mutex_for_cout);
      usleep(800);
    }
  return;
}


// Trampoline
void *	producer_start(void * p)
{
  reinterpret_cast<Producer *>(p)->start();
  return NULL;
}



/******************************************************************************/
