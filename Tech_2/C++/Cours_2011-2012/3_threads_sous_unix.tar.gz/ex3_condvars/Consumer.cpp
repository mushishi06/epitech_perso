/******************************************************************************/
/*                                                                            */
/*              Consumer.cpp in ex3_convars in 3_threads_sous_unix            */
/*              For Epitech's C++ Knowledge Unit                              */
/*              Made by : Uriel Corfa <uriel@corfa.fr>                        */
/*              Modified by : David Giron <thor@epitech.net>                  */
/*                                                                            */
/******************************************************************************/



#include <iostream>
#include <unistd.h>
#include "safe_cout.hh"

#include "DataPacket.hh"
#include "Consumer.hh"


Consumer::Consumer(int id, volatile bool* done, std::list<DataPacket *> * queue,
		   pthread_mutex_t * mutex,
		   pthread_cond_t * cond) :
  id_(id),
  done_(*done),
  queue_(queue),
  mutex_(mutex),
  cond_(cond)
{
  pthread_mutex_lock(&mutex_for_cout);
  std::cout << "New consumer..." << std::endl;
  pthread_mutex_unlock(&mutex_for_cout);
}


Consumer::~Consumer()
{
  pthread_mutex_lock(&mutex_for_cout);
  std::cout << "Delete consumer..." << std::endl;
  pthread_mutex_unlock(&mutex_for_cout);
}



/******************************************************************************/



void Consumer::start()
{
  while (true)
    {
      pthread_mutex_lock(this->mutex_);
      if (this->queue_->empty()) // Si la file est vide
	{
          pthread_mutex_lock(&mutex_for_cout);
	  std::cout << "C" << this->id_ << " is waiting..." << std::endl;
          pthread_mutex_unlock(&mutex_for_cout);
	  pthread_cond_wait(this->cond_, this->mutex_); // On attend
	  pthread_mutex_unlock(this->mutex_);
          pthread_mutex_lock(&mutex_for_cout);
	  std::cout << "C" << this->id_ << " is back into business..." << std::endl;
          pthread_mutex_unlock(&mutex_for_cout);
	  if (this->done_)
	    break;
	}
      else // Si la file n'est pas vide
	{
	  DataPacket * packet = this->queue_->front();
	  this->queue_->pop_front();
	  if (!this->queue_->empty()) // S'il reste du travail
	    {
              pthread_mutex_lock(&mutex_for_cout);
	      std::cout << "C" << this->id_ << " signaled..." << std::endl;
              pthread_mutex_unlock(&mutex_for_cout);
	      pthread_mutex_unlock(this->mutex_);
	      pthread_cond_signal(this->cond_); // On signale
	    }
	  else
	    pthread_mutex_unlock(this->mutex_);
	  delete packet; // Ensuite on consomme
	  sleep(delay_to_consume);
          pthread_mutex_lock(&mutex_for_cout);
	  std::cout << "C" << this->id_ << " consumed..." << std::endl;
          pthread_mutex_unlock(&mutex_for_cout);
          if (this->done_)
	    break;
	}
    }
  return;
}


// Trampoline
void *	consumer_start(void * c)
{
  reinterpret_cast<Consumer *>(c)->start();
  return NULL;
}



/******************************************************************************/
