/******************************************************************************/
/*                                                                            */
/*              Producer.hh in ex3_convars in 3_threads_sous_unix             */
/*              For Epitech's C++ Knowledge Unit                              */
/*              Made by : Uriel Corfa <uriel@corfa.fr>                        */
/*              Modified by : David Giron <thor@epitech.net>                  */
/*                                                                            */
/******************************************************************************/



#ifndef PRODUCER_HH_
#define PRODUCER_HH_


#include <list>
#include <pthread.h>
#include "DataPacket.hh"


// Configuration
static const unsigned int delay_to_produce = 2;


class Producer
{

public:

  Producer(int id, std::list<DataPacket *> * queue,
	   pthread_mutex_t * mutex,
	   pthread_cond_t * cond);

  ~Producer(void);

  void	start(void);

private:

  int				id_;
  std::list<DataPacket *> *	queue_;
  pthread_mutex_t *		mutex_;
  pthread_cond_t *		cond_;
 
    Producer(Producer const&);
    Producer& operator=(Producer const&);
};


// Trampoline
void *	producer_start(void * p);


#endif /* PRODUCER_HH_                                                        */



/******************************************************************************/
