/******************************************************************************/
/*                                                                            */
/*              Consumer.hh in ex3_convars in 3_threads_sous_unix             */
/*              For Epitech's C++ Knowledge Unit                              */
/*              Made by : Uriel Corfa <uriel@corfa.fr>                        */
/*              Modified by : David Giron <thor@epitech.net>                  */
/*                                                                            */
/******************************************************************************/



#ifndef CONSUMER_HH_
#define CONSUMER_HH_


#include <list>
#include <pthread.h>
#include "DataPacket.hh"


// Configuration
static const unsigned int delay_to_consume = 3;


class Consumer
{

public:

  Consumer(int id, volatile bool* done,std::list<DataPacket *> * queue,
	   pthread_mutex_t * mutex,
	   pthread_cond_t * cond);
  ~Consumer(void);

  void  start(void);

private:

  int				id_;
  volatile bool	&	       	done_;
  std::list<DataPacket *> *	queue_;
  pthread_mutex_t *		mutex_;
  pthread_cond_t *		cond_;

  Consumer(Consumer const&);
  Consumer& operator=(Consumer const&);
};


// Trampoline
void *	consumer_start(void * c);


#endif /* CONSUMER_HH_                                                        */



/******************************************************************************/
