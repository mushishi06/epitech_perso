/******************************************************************************/
/*                                                                            */
/*              safe_cout.hh in ex3_convars in 3_threads_sous_unix            */
/*              For Epitech's C++ Knowledge Unit                              */
/*              Made by : Uriel Corfa <uriel@corfa.fr>                        */
/*              Modified by : David Giron <thor@epitech.net>                  */
/*                                                                            */
/******************************************************************************/



#ifndef SAFE_COUT_HH_
#define SAFE_COUT_HH_


#include <pthread.h>


extern pthread_mutex_t  mutex_for_cout;


#endif /* SAFE_COUT_HH_                                                       */



/******************************************************************************/
