//
// genCpp.cpp for CClassCreator in /home/duret_b/Desktop/PERSO/CClassCreator
// 
// Made by Anthony DURET
// Login   <duret_b@epitech.net>
// 
// Started on  Mon Jan 23 16:21:42 2012 Anthony DURET
// Last update Tue Jan 24 03:08:08 2012 Anthony DURET
//

#include			<fstream>
#include			"HomeWindow.hpp"

static bool			createFile(QString const& name, QString const& path, QString& code)
{
  std::ofstream                 file((path.toStdString() + "/" + name.toStdString() + ".cpp").c_str(), std::ios::out | std::ios::trunc);

  if (!file)
    return (false);
  file << code.toStdString();
  file.close();

  return (true);
}

bool                            HomeWindow::genCpp()
{
  if (getName()->text().isEmpty() || (!getConstruct()->isChecked() && !getDestruct()->isChecked()))
    return (false);

  QString                       code;

  if (getComments()->isChecked())
    fillComments(code, 0);
  code += "#include			\"" + getName()->text() + ".hpp\"\n\n";
  if (getConstruct()->isChecked())
    code += getName()->text() + "::" + getName()->text() + "()\n{\n}\n\n";
  if (getDestruct()->isChecked())
    code += getName()->text() + "::~" + getName()->text() + "()\n{\n}\n\n";

  if (!createFile(getName()->text(), getDirectory()->text(),code))
    return (false);

  return (true);
}
